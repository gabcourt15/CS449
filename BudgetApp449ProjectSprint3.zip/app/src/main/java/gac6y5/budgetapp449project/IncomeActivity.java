package gac6y5.budgetapp449project;

import android.app.Activity;
import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

/**
 * Created by Gabby on 2/13/2018.
 */

public class IncomeActivity extends AppCompatActivity {
    //CREATING VARIABLES
    String totalpay;
    TextView pay;
    Button ib;

    @Override
    protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_income);

        //LINKING IDS TO VARIABLES
        pay = findViewById(R.id.grand_total);
        ib = findViewById(R.id.income_save);

        //LISTEN FOR SAVE BUTTON CLICK
        ib.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view){

                //UPDATE TOTAL INCOME VARIABLE WITH USER INPUT
                totalpay = String.valueOf(R.id.grand_total);
                //ttl = String.getText(R.id.grand_total);
                //totalpay = Float.valueOf(ttl);


                //SAVE DATA TO FILE
                SharedPreferences incomepref = getSharedPreferences("Income file", Context.MODE_PRIVATE);
                SharedPreferences.Editor editor=incomepref.edit();
                editor.putString("Total Pay",totalpay);
                editor.commit();


                //ALERT USER THAT DATA WAS SAVED
                AlertDialog.Builder incomesaved = new AlertDialog.Builder(IncomeActivity.this);
                View alert = getLayoutInflater().inflate(R.layout.alert, null);
                Button close = alert.findViewById(R.id.ok);
                TextView newview = alert.findViewById(R.id.alertbutton);
                newview.setText("Your income has been saved. You make $" + totalpay + " per month.");
                incomesaved.setView(alert);
                final AlertDialog bye = incomesaved.create();
                bye.show();
                close.setOnClickListener(new View.OnClickListener()
                {
                    @Override
                    public void onClick(View view){
                        bye.cancel();
                    }
                });
            }
        });



    }






}
