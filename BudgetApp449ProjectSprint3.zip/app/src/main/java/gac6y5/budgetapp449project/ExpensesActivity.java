package gac6y5.budgetapp449project;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

/**
 * Created by Gabby on 2/13/2018.
 */

public class ExpensesActivity extends AppCompatActivity{

    //CREATING VARIABLES
    Button eb;
    EditText house, utilities, internet, groceries, car, additional;
    float totalexpenses;

    @Override
    protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_expenses);

        //LINKING IDS TO VARIABLES
        eb=findViewById(R.id.save_exp);
        house = findViewById(R.id.house_input);
        utilities = findViewById(R.id.utilities_input);
        internet = findViewById(R.id.internet_input);
        groceries = findViewById(R.id.groceries_input);
        car = findViewById(R.id.car_input);
        additional = findViewById(R.id.additional_input);


        //LISTEN FOR SAVE BUTTON CLICK
        eb.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view)
            {

                //UPDATE TOTAL EXPENSES
                totalexpenses = Float.valueOf(house.getText().toString()) + Float.valueOf(utilities.getText().toString()) + Float.valueOf(internet.getText().toString()) + Float.valueOf(groceries.getText().toString()) + Float.valueOf(car.getText().toString()) + Float.valueOf(additional.getText().toString());


                //SAVE DATA TO FILE
                SharedPreferences expensepref = getSharedPreferences("Expenses File", Context.MODE_PRIVATE);
                SharedPreferences.Editor editor = expensepref.edit();
                editor.putFloat("house", Float.valueOf(R.id.house_input));
                editor.putFloat("utilities", Float.valueOf(R.id.utilities_input));
                editor.putFloat("internet", Float.valueOf(R.id.internet_input));
                editor.putFloat("groceries", Float.valueOf(R.id.groceries_input));
                editor.putFloat("car", Float.valueOf(R.id.car_input));
                editor.putFloat("additional", Float.valueOf(R.id.additional_input));
                editor.putFloat("Total expenses", totalexpenses);
                editor.commit();


                //ALERT USER THAT DATA WAS SAVED
                AlertDialog.Builder expensessaved = new AlertDialog.Builder(ExpensesActivity.this);
                View alert = getLayoutInflater().inflate(R.layout.alert, null);
                Button close = alert.findViewById(R.id.ok);
                TextView newview = alert.findViewById(R.id.alertbutton);
                newview.setText("Your expenses have been saved.");
                expensessaved.setView(alert);
                final AlertDialog bye = expensessaved.create();
                bye.show();
                close.setOnClickListener(new View.OnClickListener()
                {
                    @Override
                    public void onClick(View view){
                        bye.cancel();
                    }
                });
            }
        });
    }
}
