package gac6y5.budgetapp449project;

import android.app.Activity;
import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

/**
 * Created by Gabby on 2/13/2018.
 */

public class IncomeActivity extends AppCompatActivity {
    //CREATING VARIABLES
    View view;
    float totalpay, datapay;
    TextView total, hours, pay;
    Button ib;

    @Override
    protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_income);

        //LINKING IDS TO VARIABLES
        pay = findViewById(R.id.grand_total);
        ib = findViewById(R.id.income_save);

        //listen for click to save button

        ib.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view){
                //update total income variable with information entered by user
                totalpay = Float.valueOf(R.id.grand_total);

                //SAVE DATA TO FILE
                SharedPreferences incomepref = getSharedPreferences("Income file", Context.MODE_PRIVATE);
                SharedPreferences.Editor editor=incomepref.edit();
                datapay = incomepref.getFloat("Total Income",0);
                datapay = datapay + totalpay;
                editor.putFloat("Total Pay",datapay);
                editor.apply();

                //ALERT USER THAT DATA WAS SAVED
                AlertDialog.Builder incomesaved = new AlertDialog.Builder(IncomeActivity.this);
                View alert = getLayoutInflater().inflate(R.layout.alert, null);
                Button close = alert.findViewById(R.id.ok);
                TextView newview = alert.findViewById(R.id.alertbutton);
                newview.setText("Your income has been saved.");
                incomesaved.setView(alert);
                final AlertDialog bye = incomesaved.create();
                bye.show();
                close.setOnClickListener(new View.OnClickListener()
                {
                    @Override
                    public void onClick(View view){
                        bye.cancel();
                    }
                });
            }
        });



    }






}
