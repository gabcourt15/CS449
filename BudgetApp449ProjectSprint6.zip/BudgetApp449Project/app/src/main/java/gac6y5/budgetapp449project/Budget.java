package gac6y5.budgetapp449project;

/**
 * Created by Gabby on 4/21/2018.
 */

public class Budget {
    //declaring variables for use
    Float income, expenses, house, utilities, internet, groceries, car, additional;

    //constructor
    Budget()
    {
        income =0.0f;
        expenses =0.0f;
        house = 0.0f;
        utilities = 0.0f;
        internet = 0.0f;
        groceries = 0.0f;
        car =0.0f;
        additional = 0.0f;
    }
    //establishing setter methods
    void setIncome(Float i) {income =i;}

    void setExpenses(float i)
    {
        expenses = i;
    }

    void setHouse(float i)
    {
        house = i;
    }

    void setUtilities(float i)
    {
        utilities = i;
    }

    void setInternet(float i)
    {
        internet = i;
    }

    void setGroceries(float i)
    {
        groceries = i;
    }

    void setCar(float i)
    {
        car = i;
    }

    void setAdditional(float i)
    {
        additional = i;
    }

    //establishing setter methods
    Float getIncome()
    {
        return income;
    }

    Float getExpenses()
    {
        return expenses;
    }


    Float getHouse()
    {
        return house;
    }

    Float getUtilities()
    {
        return utilities;
    }

    Float getInternet()
    {
        return internet;
    }

    Float getGroceries()
    {
        return groceries;
    }

    Float getCar()
    {
        return car;
    }

    Float getAdditional()
    {
        return additional;
    }

    Float calculateTotalExpenses()
    {
        return (house + utilities + internet + groceries + car + additional);
    }
}
