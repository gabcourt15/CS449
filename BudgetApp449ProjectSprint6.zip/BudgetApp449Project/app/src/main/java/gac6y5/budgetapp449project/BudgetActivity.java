package gac6y5.budgetapp449project;

import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.widget.TextView;
import android.widget.Toast;

import com.github.mikephil.charting.charts.PieChart;
import com.github.mikephil.charting.components.Description;
import com.github.mikephil.charting.components.Legend;
import com.github.mikephil.charting.data.Entry;
import com.github.mikephil.charting.data.PieData;
import com.github.mikephil.charting.data.PieDataSet;
import com.github.mikephil.charting.data.PieEntry;
import com.github.mikephil.charting.highlight.Highlight;
import com.github.mikephil.charting.listener.OnChartValueSelectedListener;

import java.util.ArrayList;
import java.util.Map;


/**
 * Created by Gabby on 2/13/2018.
 */

public class BudgetActivity extends AppCompatActivity{

    private static String TAG = "BudgetActivity";
    float[] expenseData = {100,100,100,100,100,100};
    private String[] expenseTypes = {"Housing Expense", "Utility Expense", "Internet and Cable Expense", "Grocery Expense", "Car Expense", "Additional Expenses"};
    PieChart budgetChart;
    Budget MyBudget = new Budget();


    @Override
    public void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_budget);
        Log.d(TAG,"onCreate: starting to create chart");

        populate();

        suggestions();

        display();


    }

    //POST CONDITIONS: Graph will be populated with expense data
    private void addDataSet(PieChart budgetChart) {
        Log.d(TAG, "addDataSet started");

        ArrayList<PieEntry> expenseDataEntry = new ArrayList<>();
        for (int i=0; i < expenseData.length; i++){
            expenseDataEntry.add(new PieEntry(expenseData[i], i));
        }

        ArrayList<String> expenseTypeEntry = new ArrayList<>();
        for (int i = 0; i < expenseTypes.length; i++){
            expenseTypeEntry.add(expenseTypes[i]);
        }

        //create the data set
        PieDataSet pieDataSet = new PieDataSet(expenseDataEntry, "Expense Amount");
        pieDataSet.setSliceSpace(2);
        pieDataSet.setValueTextSize(12);

        //add colors to data set
        ArrayList<Integer> colors = new ArrayList<>();
        colors.add(Color.GRAY);
        colors.add(Color.BLUE);
        colors.add(Color.RED);
        colors.add(Color.GREEN);
        colors.add(Color.CYAN);
        colors.add(Color.YELLOW);
        colors.add(Color.MAGENTA);

        pieDataSet.setColors(colors);

        //add legend to chart
        Legend legend = budgetChart.getLegend();
        legend.setForm(Legend.LegendForm.CIRCLE);

        //Create pie data object
        PieData pieData = new PieData(pieDataSet);
        budgetChart.setData(pieData);
        budgetChart.invalidate();
    }

    void populate()
    {
        //GET INCOME DATA VIA SHARED PREFERENCES
        SharedPreferences BudgetIncomePreferences = getSharedPreferences("Income file", 0);
        float IncomeTotal = Float.parseFloat(BudgetIncomePreferences.getString("Total Pay", ""));

        //SET BUDGET DATA
        MyBudget.setIncome(IncomeTotal);

        //DISPLAY INCOME DATA ON SCREEN
        TextView income = findViewById(R.id.TotalIncome);
        income.setText(MyBudget.getIncome().toString());

        //GET EXPENSE DATA VIA SHARED PREFERENCES
        SharedPreferences  BudgetExpensePreferences = getSharedPreferences("Expense File", 0);
        float housing = BudgetExpensePreferences.getFloat("house",0);
        float utilities = BudgetExpensePreferences.getFloat("utilities",0);
        float internet = BudgetExpensePreferences.getFloat("internet",0);
        float groceries = BudgetExpensePreferences.getFloat("groceries",0);
        float car = BudgetExpensePreferences.getFloat("car",0);
        float additional = BudgetExpensePreferences.getFloat("additional",0);
        float totalexp = BudgetExpensePreferences.getFloat("total",0);

        //SET BUDGET DATA
        MyBudget.setHouse(housing);
        MyBudget.setUtilities(utilities);
        MyBudget.setInternet(internet);
        MyBudget.setGroceries(groceries);
        MyBudget.setCar(car);
        MyBudget.setAdditional(additional);
        MyBudget.setExpenses(totalexp);
    }

    void suggestions()
    {
        //DISPLAY BUDGET SUGGESTIONS ON SCREEN
        try {
            TextView suggestion = findViewById(R.id.Summary);
            if (MyBudget.getIncome() > MyBudget.getExpenses()) {
                suggestion.setText("Congrats! You have extra money to put into savings!");
            }
            else if (MyBudget.getIncome().equals(MyBudget.getExpenses())) {
                suggestion.setText("Good job! You have a balanced budget for this month!");
            }
            else if (MyBudget.getIncome() < MyBudget.getExpenses()){
                suggestion.setText("Uh Oh! Consider trying to reduce your expenses this month!");
            }
        }
        catch (NumberFormatException e)
        {
            System.err.println("NumberFormatException has occurred.");
        }
    }

    void display()
    {
        //ADD EXPENSES TO ARRAY
        //float[] expenseData = {housing, utilities, internet, groceries, car, additional};
        expenseData[0]= MyBudget.getHouse();
        expenseData[1]=MyBudget.getUtilities();
        expenseData[2]=MyBudget.getInternet();
        expenseData[3]=MyBudget.getGroceries();
        expenseData[4]=MyBudget.getCar();
        expenseData[5]=MyBudget.getAdditional();


        budgetChart = findViewById(R.id.PieChart);
        budgetChart.setRotationEnabled(true);
        budgetChart.setHoleColor(Color.DKGRAY);
        budgetChart.setCenterTextColor(Color.WHITE);
        budgetChart.setHoleRadius(25f);
        budgetChart.setCenterText("Your Budget!");
        budgetChart.setCenterTextSize(10);
        budgetChart.setTransparentCircleAlpha(0);
        budgetChart.setDrawEntryLabels(true);

        addDataSet(budgetChart);
    }
}

