package gac6y5.budgetapp449project;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;

/**
 * Created by Gabby on 2/13/2018.
 */

public class BudgetActivity extends AppCompatActivity{

    @Override
    public void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_budget);
    }
}
