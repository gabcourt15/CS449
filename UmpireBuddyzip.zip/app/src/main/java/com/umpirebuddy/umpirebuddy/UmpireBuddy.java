package com.umpirebuddy.umpirebuddy;

import android.app.AlertDialog;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.Button;
import android.widget.TextView;

public class UmpireBuddy extends AppCompatActivity {
    View view;
    Button b1, b2;
    TextView strike, balls;
    int scount = 0, bcount =0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_umpire_buddy);
        //Linking Id to variables
        strike =findViewById(R.id.strike_num);
        balls=findViewById(R.id.ball_num);
        b1=findViewById(R.id.strike_button);
        b2=findViewById(R.id.ball_button);

        //Linking count to Id of visual
        strike.setText(String.valueOf(scount));
        balls.setText(String.valueOf(bcount));


        b1.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view) {
                scount++; //increment count in code when button is clicked
                if(scount == 3) //if count is now equal to 3
                {
                    strike.setText(String.valueOf(scount)); //increment on screen
                    AlertDialog.Builder wow = new AlertDialog.Builder(UmpireBuddy.this);//create new alert
                    View hi = getLayoutInflater().inflate(R.layout.alert,null);
                    Button close = hi.findViewById(R.id.ok);
                    TextView newview = hi.findViewById(R.id.alertbutton);
                    newview.setText("Get outta here!");
                    wow.setView(hi);
                    final AlertDialog bye = wow.create();
                    bye.show();//show alert
                    close.setOnClickListener(new View.OnClickListener()
                    {
                        @Override
                        public void onClick(View view){
                        bye.cancel();
                    }
                    });

                    scount=0; //reset count
                    bcount=0;//reset count
                    strike.setText(String.valueOf(scount));//update count on screen
                    balls.setText(String.valueOf(bcount));//update count on screen
                }
                else
                {
                    strike.setText(String.valueOf(scount));
                }
            }

        });
        b2.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view){
                bcount++;
                if (bcount == 4)
                {
                    balls.setText(String.valueOf(bcount));
                    AlertDialog.Builder wow = new AlertDialog.Builder(UmpireBuddy.this);//create new alert
                    View hi = getLayoutInflater().inflate(R.layout.alert,null);
                    Button close = hi.findViewById(R.id.ok);
                    TextView newview = hi.findViewById(R.id.alertbutton);
                    newview.setText("You can walk...");
                    wow.setView(hi);
                    final AlertDialog bye = wow.create();
                    bye.show();//show alert
                    close.setOnClickListener(new View.OnClickListener()
                    {
                        @Override
                        public void onClick(View view){
                            bye.cancel();
                        }
                    });
                    scount=0;
                    bcount=0;
                    strike.setText(String.valueOf(scount));
                    balls.setText(String.valueOf(bcount));
                }
                else
                {
                    balls.setText(String.valueOf(bcount));
                }
            }
        });
    }



    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_umpire_buddy, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }
}
