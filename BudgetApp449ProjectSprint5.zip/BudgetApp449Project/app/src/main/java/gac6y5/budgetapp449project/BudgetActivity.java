package gac6y5.budgetapp449project;

import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.widget.TextView;
import android.widget.Toast;

import com.github.mikephil.charting.charts.PieChart;
import com.github.mikephil.charting.components.Description;
import com.github.mikephil.charting.components.Legend;
import com.github.mikephil.charting.data.Entry;
import com.github.mikephil.charting.data.PieData;
import com.github.mikephil.charting.data.PieDataSet;
import com.github.mikephil.charting.data.PieEntry;
import com.github.mikephil.charting.highlight.Highlight;
import com.github.mikephil.charting.listener.OnChartValueSelectedListener;

import java.util.ArrayList;
import java.util.Map;

/**
 * Created by Gabby on 2/13/2018.
 */

public class BudgetActivity extends AppCompatActivity{

    private static String TAG = "BudgetActivity";
    float[] expenseData = {100,100,100,100,100,100};
    private String[] expenseTypes = {"Housing Expense", "Utility Expense", "Internet and Cable Expense", "Grocery Expense", "Car Expense", "Additional Expenses"};
    PieChart budgetChart;


    @Override
    public void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_budget);
        Log.d(TAG,"onCreate: starting to create chart");

        //GET INCOME DATA VIA SHARED PREFERENCES
        SharedPreferences BudgetIncomePreferences = getSharedPreferences("Income file", 0);
        float IncomeTotal = Float.parseFloat(BudgetIncomePreferences.getString("Total Pay", ""));


        //DISPLAY INCOME DATA ON SCREEN
        TextView income = findViewById(R.id.TotalIncome);
        income.setText(String.valueOf(IncomeTotal));

        //GET EXPENSE DATA VIA SHARED PREFERENCES
       SharedPreferences  BudgetExpensePreferences = getSharedPreferences("Expenses File", 0);
       float housing = BudgetExpensePreferences.getFloat("house",0);
       float utilities = BudgetExpensePreferences.getFloat("utilities",0);
       float internet = BudgetExpensePreferences.getFloat("internet",0);
       float groceries = BudgetExpensePreferences.getFloat("groceries",0);
       float car = BudgetExpensePreferences.getFloat("car",0);
       float additional = BudgetExpensePreferences.getFloat("additional",0);
       float ExpenseTotal = BudgetExpensePreferences.getFloat("expense total", 0);
        //Gson gson = new Gson();
        //String json = incomepref.getString("MyBudget","");
        //Budget MyBudget = gson.fromJson(json, MyBudget.class);
       //DISPLAY EXPENSE DATA ON SCREEN
        TextView expense = findViewById(R.id.TotalExpense);
        expense.setText(String.valueOf(ExpenseTotal));

        //DISPLAY BUDGET SUGGESTIONS ON SCREEN
        try {
            TextView suggestion = findViewById(R.id.Summary);
            if (Float.valueOf(income.getText().toString()) > Float.valueOf(expense.getText().toString())) {
                suggestion.setText("Congrats! You have extra money to put into savings!");
            } else if (Float.valueOf(income.getText().toString()) == Float.valueOf(expense.getText().toString())) {
                suggestion.setText("Good job! You have a balanced budget for this month!");
            } else {
                suggestion.setText("Uh Oh! Consider trying to reduce your expenses this month!");
            }
        }
        catch (NumberFormatException e)
        {
            System.err.println("NumberFormatException has occurred.");
        }

       //ADD EXPENSES TO ARRAY
       //float[] expenseData = {housing, utilities, internet, groceries, car, additional};
        expenseData[0]= housing;
        expenseData[1]=utilities;
        expenseData[2]=internet;
        expenseData[3]=groceries;
        expenseData[4]=car;
        expenseData[5]=additional;


        budgetChart = findViewById(R.id.PieChart);
        budgetChart.setRotationEnabled(true);
        budgetChart.setHoleColor(Color.DKGRAY);
        budgetChart.setCenterTextColor(Color.WHITE);
        budgetChart.setHoleRadius(25f);
        budgetChart.setCenterText("Your Budget!");
        budgetChart.setCenterTextSize(10);
        budgetChart.setTransparentCircleAlpha(0);
        budgetChart.setDrawEntryLabels(true);
        //budgetChart.setEntryLabelTextSize(20);

        addDataSet(budgetChart);

        /*budgetChart.setOnChartValueSelectedListener(new OnChartValueSelectedListener() {
            @Override
            public void onValueSelected(Entry e, Highlight h) {
                Log.d(TAG, "onValueSelected: Value select from chart.");
                Log.d(TAG, "onValue Selected:" + e.toString());
                Log.d(TAG, "onValueSelected:" + h.toString());

                int pos1 = e.toString().indexOf("(sum): ");
                String expenses = e.toString().substring(pos1 + 7);

                for (int i = 0; i <expenseData.length; i++)
                {
                    if (expenseData[i] == Float.parseFloat(expenses)){
                        pos1 = i;
                        break;
                    }
                }
                String Expense_name = expenseTypes[pos1 +1];
                Toast.makeText(BudgetActivity.this, Expense_name + ": " + "$" + expenses, Toast.LENGTH_LONG).show();
            }

            @Override
            public void onNothingSelected() {

            }
        });*/

    }

    //POST CONDITIONS: Graph will be populated with expense data
    private void addDataSet(PieChart budgetChart) {
         Log.d(TAG, "addDataSet started");

        ArrayList<PieEntry> expenseDataEntry = new ArrayList<>();
        for (int i=0; i < expenseData.length; i++){
            expenseDataEntry.add(new PieEntry(expenseData[i], i));
        }

        ArrayList<String> expenseTypeEntry = new ArrayList<>();
        for (int i = 0; i < expenseTypes.length; i++){
            expenseTypeEntry.add(expenseTypes[i]);
        }

        //create the data set
        PieDataSet pieDataSet = new PieDataSet(expenseDataEntry, "Expense Amount");
        pieDataSet.setSliceSpace(2);
        pieDataSet.setValueTextSize(12);

        //add colors to data set
        ArrayList<Integer> colors = new ArrayList<>();
        colors.add(Color.GRAY);
        colors.add(Color.BLUE);
        colors.add(Color.RED);
        colors.add(Color.GREEN);
        colors.add(Color.CYAN);
        colors.add(Color.YELLOW);
        colors.add(Color.MAGENTA);

        pieDataSet.setColors(colors);

        //add legend to chart
        Legend legend = budgetChart.getLegend();
        legend.setForm(Legend.LegendForm.CIRCLE);

        //Create pie data object
        PieData pieData = new PieData(pieDataSet);
        budgetChart.setData(pieData);
        budgetChart.invalidate();
    }
}

